#ifndef STORE_H
#define STORE_H

#include <string>
using namespace std;

struct store {
    string name;

    store() : name("") {} // default constructor

    store(const string& name) {
        this->name = name;
    }

    bool operator==(const store& shop) const {
        return this->name == shop.name;
    }

    bool operator<(const store& shop) const {
        return this->name < shop.name;
    }
};

#endif