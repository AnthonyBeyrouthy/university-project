#include "Pesticide.h"

pesticide::pesticide() {
	this->name = "";
	this->manufacturing_company = "";
	this->weather = "";
	this->location = "";
	this->temperature = 0;
	specification["Bad nutrition"] = false;
	specification["Presence of insects"] = false;
	specification["Small size of the fruit"] = false;
	specification["Discoloration in the sleaves"] = false;
}

pesticide::pesticide(string name, string manufacturing_company, string weather, string location, int temperature, array<bool,4> require, map <store, int> stores) {
	this->name = name;
	this->manufacturing_company = manufacturing_company;
	this->weather = weather;
	this->location = location;
	this->temperature = temperature;
	specification["Bad nutrition"] = require[0];
	specification["Presence of insects"] = require[1];
	specification["Small size of the fruit"] = require[2];
	specification["Discoloration in the sleaves"] = require[3];
	this->stores = stores;
}

pesticide::~pesticide() {}

void pesticide::printpesticide() {
	cout << "Name : " << name << endl;
	cout << "Manufacturing Company : " << manufacturing_company << endl;
	cout << "Weather condition usage : " << weather << endl;
	cout << "Ideal location of usage : " << location << endl;
	cout << "Temperature requirement : " << temperature << endl;
	cout << "Usage purpose : " << endl;
	for (pair<string, bool> pair : specification) {
		if (pair.second) {
			cout << pair.first << endl;
		}
	}
	cout << "Available at the following stores : " << endl;
	int i = 1;
	for (pair<store, int> pair : stores) {
		if (pair.second != 0) {
			cout << i <<"- " << pair.first.name << " : " << pair.second << endl;
			i++;
		}
		else {
			cout << pair.first.name << " doesn't have " << name << endl;
		}
	}
}

void pesticide::decrement_from_the_store(store shop) {
	if (stores.find(shop) == stores.end()) {
		cout << "the shop doesn't exist in our system." << endl;
	}
	else {
		stores[shop]--;
		cout << "The pesticide will arrive to your destination after 24 hours." << endl;
	}
}

map <store, int> pesticide::getstores() {
	return this->stores;
}
