#ifndef BinaryNode_h
#define BinaryNode_h
#include "tree.h"

struct BinaryNode
{
	tree data; //Data in the node
	BinaryNode* left; //Left child node
	BinaryNode* right; //Right child node
	//Constructor
	BinaryNode(const tree& d, BinaryNode* l, BinaryNode* r)
	{
		data = d; left = l; right = r;
	}
};
#endif
