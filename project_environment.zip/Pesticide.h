#ifndef PESTICIDE_H
#define PESTICIDE_H
#include <iostream>
using namespace std;
#include <string>
#include <array>
#include <map>
#include "store.h"

class pesticide {
private:
	string name;
	string manufacturing_company;
	string weather;
	string location;
	int temperature;
	map <string, bool> specification;
	map <store,int> stores;
public:
	pesticide();
	pesticide(string, string, string, string, int, array<bool,4> , map<store,int>);
	~pesticide();
	void printpesticide();
	void decrement_from_the_store(store);
	map <store, int> getstores();
};

#endif
