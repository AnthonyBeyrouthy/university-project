#include "TypeTree.h"
#include <cstdlib>

string getmonth(int);

void typetree::setpesticides(array <pesticide,5> sc) {
	time_t now = time(0);
	tm ltm;          // not a pointer anymore
	localtime_s(&ltm, &now);

	int month = 1 + ltm.tm_mon;

	if (schedule_pesticide.find(month) != schedule_pesticide.end()) {
		schedule_pesticide[month] = sc;
	}
}

array<pesticide, 5> typetree::getpesticides() {
	time_t now = time(0);
	tm ltm;          // not a pointer anymore
	localtime_s(&ltm, &now);

	int month = 1 + ltm.tm_mon;

	if (schedule_pesticide.find(month) != schedule_pesticide.end()) {
		return schedule_pesticide[month];
	}
	else {
		cout << "No pesticide required for this month." << endl;
		return {};
	}
}

long long typetree::getId() const {
	return Id;
}

typetree& typetree::operator=(const typetree& other) {
	this->Id = other.Id;
	this->name = other.name;
	this->Qty = other.Qty;
	this->cuttingduration = other.cuttingduration;
	this->schedule_pesticide = other.schedule_pesticide;
	return *this;
}

typetree::typetree(const typetree& other) {
	this->Id = other.Id;
	this->name = other.name;
	this->Qty = other.Qty;
	this->cuttingduration = other.cuttingduration;
	this->schedule_pesticide = other.schedule_pesticide;
}

string typetree::getname() const {
	return name;
}

int typetree::getduration() const {
	return cuttingduration;
}

bool Idexist(long long Id, const set<typetree>& trees) {
	for (const typetree& value : trees) {
		if (value.getId() == Id) {
			return true;
		}
	}
	return false;
}

long long generateID(const std::set<typetree>& trees) {
	bool seeded = false;
	if (!seeded) {
		srand(static_cast<unsigned int>(time(0)));
		seeded = true;
	}

	long long id;
	do {
		id = static_cast<long long>(rand() % 900) + 100;  // or use larger range
	} while (Idexist(id, trees));

	return id;
}

bool typetree::operator==(const typetree& other) const {
	return this->name == other.name &&
		this->Qty == other.Qty &&
		this->Id == other.Id;  // Now consistent with operator<
}

bool typetree::operator<(const typetree& other) const {
	if (this->name == other.name) {
		if (this->Qty == other.Qty) {
			return this->Id < other.Id;  // Adding Id to make comparisons more specific
		}
		return this->Qty < other.Qty;
	}
	return this->name < other.name;
}


typetree::typetree() {
	this->Id = 0;
	this->name = "";
	this->Qty = 0;
	this->cuttingduration = 0;
}

typetree::typetree(const set<typetree>& trees,string name, int Qty,int cuttingduration ,map <int, array<pesticide,5>> schedule_pesticide) {
	this-> Id = generateID(trees);
	this->name = name;
	this->Qty = Qty;
	this->cuttingduration = cuttingduration;
	this->schedule_pesticide = schedule_pesticide;
}

typetree::~typetree() {}

void typetree::incrementQty() {
	this->Qty++;
}

void typetree::decrementQty() {
	this->Qty--;
}

void typetree::printtypetreeinfo() const {
	cout << "The tree is of type " << name << endl;
	cout << "there is exist in our system " << Qty << " " << name << " tree." << endl;
	cout << name << " tree needs to be cutted after " << cuttingduration << " years." << endl;
}

array<pesticide,5> typetree::search_pesticide(int month) {
	if (schedule_pesticide.find(month) == schedule_pesticide.end()) {
		cout << "In " << getmonth(month) << ", " << name << "tree doesn't require pesticide." << endl;
		array <pesticide, 5> a;
		return a;
	}
	else {
		return schedule_pesticide[month];
	}
}

string getmonth(int number) {
	// Array of month names, 1-based index
	const string months[] = {
		"", // Index 0 is unused
		"January", "February", "March", "April", "May", "June",
		"July", "August", "September", "October", "November", "December"
	};

	// Check if the number is within valid month range (1 to 12)
	if (number < 1 || number > 12) {
		return "Invalid month";  // or return an empty string, depending on your need
	}

	return months[number];
}

