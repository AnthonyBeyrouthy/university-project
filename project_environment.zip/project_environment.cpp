﻿#include <iostream>
#include <iomanip>
#include <sstream>
#include <ctime>
#include "BinarySearchTree.h"
#include "Tree.h"
#include "TypeTree.h"
#include "Pesticide.h"
#include "store.h"
#include <string>
#include <set>
#include <map>
#include <queue>
using namespace std;

int welcomepage();
int activity1();
int activity2();
void task1to1(set<typetree>&,BinarySearchTree&);
void task2to1(const BinarySearchTree&);
void task3to1(const BinarySearchTree&);
void task1to2(const BinarySearchTree&);
void task2to2(set<typetree>&, BinarySearchTree&);
void activity3(const BinarySearchTree&);

int main() {
	
	BinarySearchTree TREES;
	set<typetree> TYPES;
	map<store, int> stores;
	stores[store("Alibaba")] = 5;
	stores[store("Pesticide.com")] = 5;
	stores[store("AgriPest")] = 5;
	stores[store("LoveNature")] = 5;
	stores[store("Planticide")] = 5;
	pesticide phosphate("phosphate", "UNIFERT", "RAINY", "montain", 18, { true,false,true,false }, stores);
	pesticide cobalt("cobalt", "UNIFERT", "SUNNY", "coast", 30, { true,false,false,false }, stores);
	pesticide Nitrate("Nitrate", "UNIFERT", "cold", "coast", 10, { false,false,true,false }, stores);
	pesticide antiinsect("antiinsect", "UNIFERT", "RAINY", "montain", 11, { false,true,true,false }, stores);
	pesticide nichrome("nichrome", "UNIFERT", "Sunny", "montain", 24, { true,false,true,true }, stores);
	pesticide GlyphoGreen("GlyphoGreen", "UNIFERT", "cold", "coast", 18, { false,false,true,true }, stores);
	pesticide HerbiSafe("HerbiSafe", "UNIFERT", "RAINY", "coast", 20, { false,true,false,false }, stores);
	pesticide AgriTox("AgriTox", "UNIFERT", "RAINY", "montain", 18, { false,false,true,false }, stores);
	pesticide PlantGuard("PlantGuard", "UNIFERT", "Sunny", "montain", 25, { true,true,true,false }, stores);
	map <int, array<pesticide,5>> peachSc;
	peachSc[0] = array<pesticide,5> { AgriTox,HerbiSafe,PlantGuard,antiinsect,phosphate };
	peachSc[5] = array<pesticide, 5> { GlyphoGreen, HerbiSafe, cobalt, antiinsect, nichrome };
	peachSc[10] = array<pesticide, 5> { AgriTox, Nitrate, PlantGuard, GlyphoGreen, HerbiSafe };
	map <int, array<pesticide, 5>> AppleSc;
	AppleSc[2] = array<pesticide, 5> { AgriTox, HerbiSafe, PlantGuard, antiinsect, phosphate };
	AppleSc[7] = array<pesticide, 5> { GlyphoGreen, HerbiSafe, cobalt, antiinsect, nichrome };
	AppleSc[11] = array<pesticide, 5> { AgriTox, Nitrate, PlantGuard, GlyphoGreen, HerbiSafe };
	map <int, array<pesticide, 5>> orangeSc;
	orangeSc[1] = array<pesticide, 5> { AgriTox, HerbiSafe, PlantGuard, antiinsect, phosphate };
	orangeSc[4] = array<pesticide, 5> { GlyphoGreen, HerbiSafe, cobalt, antiinsect, nichrome };
	orangeSc[7] = array<pesticide, 5> { AgriTox, Nitrate, PlantGuard, GlyphoGreen, HerbiSafe };
	map <int, array<pesticide, 5>> oliveSc;
	oliveSc[6] = array<pesticide, 5> { AgriTox, HerbiSafe, PlantGuard, antiinsect, phosphate };
	oliveSc[3] = array<pesticide, 5> { GlyphoGreen, HerbiSafe, cobalt, antiinsect, nichrome };
	oliveSc[9] = array<pesticide, 5> { AgriTox, Nitrate, PlantGuard, GlyphoGreen, HerbiSafe };
	map <int, array<pesticide, 5>> pineappleSc;
	pineappleSc[11] = array<pesticide, 5> { AgriTox, HerbiSafe, PlantGuard, antiinsect, phosphate };
	pineappleSc[7] = array<pesticide, 5> { GlyphoGreen, HerbiSafe, cobalt, antiinsect, nichrome };
	pineappleSc[0] = array<pesticide, 5> { AgriTox, Nitrate, PlantGuard, GlyphoGreen, HerbiSafe };
	map <int, array<pesticide, 5>> avocadoSc;
	avocadoSc[9] = array<pesticide, 5> { AgriTox, HerbiSafe, PlantGuard, antiinsect, phosphate };
	avocadoSc[2] = array<pesticide, 5> { GlyphoGreen, HerbiSafe, cobalt, antiinsect, nichrome };
	avocadoSc[4] = array<pesticide, 5> { AgriTox, Nitrate, PlantGuard, GlyphoGreen, HerbiSafe };
	map <int, array<pesticide, 5>> cherrySc;
	cherrySc[2] = array<pesticide, 5> { AgriTox, HerbiSafe, PlantGuard, antiinsect, phosphate };
	cherrySc[4] = array<pesticide, 5> { GlyphoGreen, HerbiSafe, cobalt, antiinsect, nichrome };
	cherrySc[6] = array<pesticide, 5> { AgriTox, Nitrate, PlantGuard, GlyphoGreen, HerbiSafe };
	cherrySc[8] = array<pesticide, 5> { phosphate, nichrome, cobalt, GlyphoGreen, AgriTox };
	typetree Peach(TYPES, "Peach", 0, 5, peachSc);
	TYPES.insert(Peach);
	typetree Apple(TYPES, "Apple", 0, 12, AppleSc);
	TYPES.insert(Apple);
	typetree Orange(TYPES, "Orange", 0, 10, orangeSc);
	TYPES.insert(Orange);
	typetree Olive(TYPES, "Olive", 0, 7, oliveSc);
	TYPES.insert(Olive);
	typetree Pineapple(TYPES, "Pineapple", 0, 8, pineappleSc);
	TYPES.insert(Pineapple);
	typetree Avocado(TYPES, "Avocado", 0, 9, avocadoSc);
	TYPES.insert(Avocado);
	typetree Cherry(TYPES, "Cherry", 0, 10, cherrySc);
	TYPES.insert(Cherry);
	tree tree1(0, "Anthony El Beyrouthy", "Zouk", Apple, TREES,TYPES);
	TREES.Insert(tree1);
	tree tree2(457, "Anthony El Beyrouthy", "New York", Peach, TREES,TYPES);
	TREES.Insert(tree2);
	tree tree3("Anthony El Beyrouthy", "Beirut", Pineapple, TREES, TYPES);
	TREES.Insert(tree3);
	tree tree4("Anthony El Beyrouthy", "Zouk", Avocado, TREES,TYPES);
	TREES.Insert(tree4);
	tree tree5(0, "Yves Dagher", "New York", Olive, TREES,TYPES);
	TREES.Insert(tree5);
	tree tree6(457, "Yves Dagher", "Beirut", Cherry, TREES,TYPES);
	TREES.Insert(tree6);
	tree tree7("Yves Dagher", "Tripoli", Orange, TREES,TYPES);
	TREES.Insert(tree7);
	tree tree8("Yves Dagher", "New York", Avocado, TREES,TYPES);
	bool a = true;
	int activity, tasks;
	do {
		activity = welcomepage();
		switch (activity) {
		case 1:
			tasks = activity1();
			switch (tasks) {
			case 1:
				task1to1(TYPES, TREES);
				break;
			case 2:
				task2to1(TREES);
				break;
			case 3:
				task3to1(TREES);
				break;
			default:
				a = false;
			};
			break;
		case 2:
			tasks = activity2();
			switch (tasks) {
			case 1:
				task1to2(TREES);
				break;
			case 2:
				task2to2(TYPES, TREES);
				break;
			default:
				a = false;
			};
			break;
		case 3:
			activity3(TREES);
			break;
		default:
			a = false;
		};
	} while (a);
	return 0;
}

int welcomepage() {
	std::cout << "-------------------------------------------- Welcome to enviroment care system --------------------------------------------------"
	     << "\nIf you have to manage a tree profile, press 1." << endl
	     << "If you want to check that your tree should be cutted, press 2." << endl
	     << "If you want to check the type of pesticide required, press 3." << endl;
	int prompt;
	do {
		std::cout << "Enter the following number:";
		cin >> prompt;
	} while (prompt < 0 && prompt >= 4);
	return prompt;
}

int activity1() {
	std::cout << "---------------------------------------------------------------------------------------------------------------------------------\n";
	std::cout << "If you have to add a new tree profile, press 1." << endl;
	std::cout << "If you want to see your trees, press 2." << endl;
	std::cout << "If you want to display all trees, press 3." << endl;
	int prompt;
	do {
		std::cout << "Enter the following number:";
		cin >> prompt;
	} while (prompt < 0 && prompt >= 4);
	return prompt;
}

int activity2() {
	std::cout << "---------------------------------------------------------------------------------------------------------------------------------\n";
	std::cout << "If you have to display all cuttable tree, press 1." << endl;
	std::cout << "If you want to remove your cutted tree from the system, press 2." << endl;
	int prompt;
	do {
		std::cout << "Enter the following number:";
		cin >> prompt;
	} while (prompt < 0 && prompt >= 4);
	return prompt;
}

void activity3(const BinarySearchTree& tr) {
	tree tre;
	bool found = false;
	do {
		std::cout << "----------------------------------------------------------------------------------------------------------------------------------\n";
		std::cout << "Enter the ID: ";
		int a;
		cin >> a;
		tre = tr.Contains(a);
		// Assuming Contains() returns a bool, and you can get the tree via a different method
		if (tre.getId()) {  // If the tree contains the ID
			found = true;
		}
		else {
			std::cout << "The tree with ID " << a << " is not found." << endl;
		}

	} while (!found);
	typetree typeee = tre.gettype();
	array <pesticide, 5> sc = typeee.getpesticides();
	if (!sc.empty()) {
		int i = 0;
		for (pesticide value :sc) {
			cout << "----------------------------------------------------------------------------------------------------------------------------------\n";
			cout << "----------------------------------------------------------"<<i <<"-----------------------------------------------------------------------\n";
			cout << "----------------------------------------------------------------------------------------------------------------------------------\n";
			value.printpesticide();
			i++;
		}
		cout << "Choose pesticide number or skip by pressing any number : ";
		int a;
		cin >> a;
		cout << "Choose stores number to buy pesticide or skip by pressing any number : ";
		int prompt;
		cin >> prompt; 
		pesticide pes;
		if (prompt < 6 && prompt > 0 && a > 0 && a < 6) {
			pes = sc[a - 1];
			int b = 1;
			for (pair<store, int> value : pes.getstores()) {
				if (b == prompt) {
					pes.decrement_from_the_store(value.first);
					sc[a - 1] = pes;
					typeee.setpesticides(sc);
				}
				b++;
			}
		}
	}
}

void task1to1(set <typetree>& ty, BinarySearchTree& tr) {
	std::cout << "----------------------------------------------------------------------------------------------------------------------------------";
	string name, location;
	int selection;
	typetree t;
	std::cout << "\nEnter your full name : ";
	cin >> name;
	std::cout << "\nEnter your tree location : ";
	cin >> location;
	std::cout << "\nChoose your tree type: " << endl;
	int i = 1;
	for (typetree value : ty) {
		std::cout << i << "- " << value.getname() << endl;
		i++;
	}
	do {
		std::cout << "Enter your tree type number : ";
		cin >> selection;
	} while (selection <= 0 && selection >= 8);
	auto it = ty.begin();
	switch (selection) {
	case 1:
		t = *(it);
		break;
	case 2:
		advance(it, 1);
		t = *it;
		break;
	case 3:
		advance(it, 2);
		t = *it;
		break;
	case 4:
		advance(it, 3);
		t = *it;
		break;
	case 5:
		advance(it, 4);
		t = *it;
		break;
	case 6:
		advance(it, 5);
		t = *it;
		break;
	case 7:
		advance(it, 6);
		t = *it;
		break;
	};
	tree tre(name, location, t, tr,ty);
	tr.Insert(tre);
	std::cout << "The tree is succesfully added" << endl;
	std::cout << "----------------------------------------------------------------------------------------------------------------------------------\n";
	tre.printtree();
}

void task2to1(const BinarySearchTree& tr){
	bool found = false;
	tree tre;  // A variable to store the tree if found
	do {
		std::cout << "----------------------------------------------------------------------------------------------------------------------------------\n";
		std::cout << "Enter the ID: ";
		int a;
		cin >> a;
		tre = tr.Contains(a);
		// Assuming Contains() returns a bool, and you can get the tree via a different method
		if (tre.getId()) {  // If the tree contains the ID
			found = true;
			tre.printtree();  // Print the tree
		}
		else {
			std::cout << "The tree with ID " << a << " is not found." << endl;
		}

	} while (!found);
}

void task3to1(const BinarySearchTree& tr) {
	tr.PrintTree();
}

void task1to2(const BinarySearchTree& tr) {
	tr.PrintCutTree();
}

void task2to2(set<typetree>& ty, BinarySearchTree& tr) {
	bool found = false;
	tree tre;  // A variable to store the tree if found
	do {
		std::cout << "----------------------------------------------------------------------------------------------------------------------------------\n";
		std::cout << "Enter the ID: ";
		int a;
		cin >> a;
		tre = tr.Contains(a);
		// Assuming Contains() returns a bool, and you can get the tree via a different method
		if (tre.getId()) {  // If the tree contains the ID
			found = true;
			tre.printtree();  // Print the tree
		}
		else {
			std::cout << "The tree with ID " << a << " is not found." << endl;
		}

	} while (!found);
	typetree typeee = tre.gettype();
	for (auto it = ty.begin(); it != ty.end(); ++it) {
		if (*it == typeee) {
			ty.erase(it); // erase the iterator
			typeee.decrementQty();
			ty.insert(typeee); // reinsert
			found = true;
			break;
		}
	}
	// Remove from the other container
	tr.Remove(tre);
}
