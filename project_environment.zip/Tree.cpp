#include "Tree.h"
#include <sstream>
#include <iomanip>
#include "BinarySearchTree.h"
#include "TypeTree.h"
#include <ctime>
#include <cstdlib>

string GetTimestamp(time_t);

tree& tree::operator=(const tree& other) {
	if (this != &other) {  // Check for self-assignment
		this->Id = other.Id;  // Copy the ID
		this->Creation_Date = other.Creation_Date;  // Copy creation date
		this->owner = other.owner;  // Copy owner
		this->location = other.location;  // Copy location
		this->cuttingday = other.cuttingday;  // Copy cutting day
		this->cutted = other.cutted;  // Copy cutted status
		this->type = other.type;  // Copy tree type (this will call the copy constructor of typetree)
	}
	return *this;  // Return the current object
}

tree::tree(string owner, string location, typetree& type, BinarySearchTree& trees,set<typetree>& types) :
	tree(time(0), owner, location, type, trees,types) {};

long long tree::getId() const {
	return Id;
}

typetree tree::gettype() const{
	return this->type;
}

tree::tree()
{
	Id = 0;
	Creation_Date = 0;
	owner = "";
	location = "";
	cutted = false;
	cuttingday = 0;
	type = typetree(); // assuming typetree has a default constructor
}

tree::tree(time_t Creation_Date, string owner, string location, typetree& type, BinarySearchTree& trees, set<typetree>& types) {
	this->Id = trees.generateID(rand() % 10000) + type.getId() * 10000;
	this->Creation_Date = Creation_Date;
	this->owner = owner;
	this->location = location;
	this->cutted = false;
	this->cuttingday = static_cast<time_t>(type.getduration() * 31536000) + Creation_Date;

	// Find the actual object in the set
	auto it = std::find_if(types.begin(), types.end(), [&](const typetree& t) {
		return t.getId() == type.getId();
		});

	if (it != types.end()) {
		// Copy, modify, and reinsert
		typetree updated = *it;     // Copy from set
		types.erase(it);            // Erase the original
		updated.incrementQty();     // Now modify the copy
		types.insert(updated);      // Insert updated version
		this->type = updated; // Store the type for this tree
	}
	else {
		std::cout << "Type with ID " << type.getId() << " not found in set.\n";
	}
}


tree::~tree(){}

void tree::printtree() {
	cout << "-------------------------------------------------------------------------------------------------------------------------------------------\n";
	cout << "The tree owned by " << owner << " of ID " << Id << " is planted in " << location << " on " << GetTimestamp(Creation_Date) << ", and should be cutted " << GetTimestamp(cuttingday) << "." << endl;
	type.printtypetreeinfo();
	if (!cutted && Iscutable(time(0))) {
		cout << "This " << type.getname() << " tree should be cutted as soon as possible because it becomes to old." << endl;
	}
}

bool tree::Iscutable(time_t time) const {
	return time > cuttingday;
}

bool tree::operator==(const tree& other) const {
	// Compare each member variable for equality
	return this->Id == other.Id &&
		this->Creation_Date == other.Creation_Date &&
		this->owner == other.owner &&
		this->location == other.location &&
		this->cutted == other.cutted &&
		this->cuttingday == other.cuttingday &&
		this->type == other.type;
}

// Returns the tree's age in years
int tree::Age(time_t current_time) {
	// Calculate the difference in time and convert to years
	double diff = difftime(current_time, Creation_Date);
	return static_cast<int>(diff / (60 * 60 * 24 * 365.25));  // Adjust for leap years
}

string GetTimestamp(time_t T)
{
	tm localTime;
	localtime_s(&localTime, &T); // Safe version!

	stringstream ss;
	ss << setfill('0')
		<< setw(2) << localTime.tm_mday << '/'
		<< setw(2) << (localTime.tm_mon + 1) << '/'  // Month is zero-based in tm
		<< (localTime.tm_year + 1900) << ' '
		<< setw(2) << (localTime.tm_hour % 12 == 0 ? 12 : localTime.tm_hour % 12) << ':' // 12-hour format
		<< setw(2) << localTime.tm_min << ':'
		<< setw(2) << localTime.tm_sec << ' '
		<< (localTime.tm_hour < 12 ? "AM" : "PM");

	return ss.str();
}