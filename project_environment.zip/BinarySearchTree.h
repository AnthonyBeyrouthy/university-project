#ifndef BinarySearchTree_h
#define BinarySearchTree_h
#include "Tree.h"
#include "BinaryNode.h"

class BinarySearchTree
{
private:
	BinaryNode* root;
	//Utility functions
	BinaryNode* Clone(BinaryNode*) const;
	void MakeEmpty(BinaryNode*&);
	tree Contains(const int&, BinaryNode*) const;
	void Insert(const tree&, BinaryNode*&);
	void Remove(const tree&, BinaryNode*&);
	void PrintTree(BinaryNode*) const;
	void PrintCutTree(BinaryNode*) const;
	tree FindMin(BinaryNode*) const;
	bool idExists(BinaryNode*, int);
	int generateID(BinaryNode*, int);
public:
	//Constructor
	BinarySearchTree();
	//Copy constructor
	BinarySearchTree(
		const BinarySearchTree&);
	//Destructor
	~BinarySearchTree();
	//Predicate function
	bool IsEmpty() const;
	//Print function
	void PrintTree() const;
	void PrintCutTree() const;
	//Tree functions
	tree Contains(const int&) const;
	void MakeEmpty();
	tree FindMin() const;
	void Insert(const tree&);
	void Remove(const tree&);
	bool idExists(int Id);
	int generateID(int Id);
};
#endif
