#ifndef TYPETREE_h
#define TYPETREE_h
#include <iostream>
using namespace std;
#include <string>
#include <set>
#include <map>
#include "Pesticide.h"


class typetree {
	friend bool Idexist(long long, const set<typetree>&);
	friend long long generateID(const set<typetree>&);
private:
	long long Id;
	string name;
	int Qty;
	int cuttingduration;
	map <int, array<pesticide,5>> schedule_pesticide;
public:
	array<pesticide, 5> getpesticides();
	bool operator==(const typetree&) const;
	bool operator<(const typetree&) const;
	typetree();
	typetree& operator=(const typetree& other);
	typetree(const typetree&);
	typetree(const set<typetree>&, string, int, int, map < int, array<pesticide,5>>);
	~typetree();
	void setpesticides(array <pesticide, 5>);
	long long getId() const;
	string getname() const;
	int getduration() const;
	void incrementQty();
	void decrementQty();
	void printtypetreeinfo() const ;
	array<pesticide,5> search_pesticide(int);
};

#endif