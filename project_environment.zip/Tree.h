#ifndef TREE_H
#define TREE_H
#include<iostream>
#include<string>
#include "TypeTree.h"
class BinarySearchTree;
using namespace std;

class BinarySearchTree;

class tree {
private:
	long long Id;
	time_t Creation_Date;
	string owner;
	bool cutted;
	string location;
	time_t cuttingday;
	typetree type;
public:
	typetree gettype() const;
	bool operator==(const tree&) const;
	tree& operator=(const tree&);
	tree();
	tree(string, string, typetree&, BinarySearchTree&, set<typetree>&);
	tree(time_t,string, string, typetree&, BinarySearchTree&, set<typetree>&);
	long long getId() const;
	~tree();
	void printtree();
	bool Iscutable(time_t) const;
	int Age(time_t);
};

#endif
