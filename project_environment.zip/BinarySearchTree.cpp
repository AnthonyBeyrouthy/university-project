#include "BinarySearchTree.h"
#include <cstdlib>

bool BinarySearchTree::idExists(int Id) {
	return idExists(root, Id);
}

bool BinarySearchTree::idExists(BinaryNode* root, int Id) {
	if (!root) return false;
	if ((root->data).getId() == Id) return true;
	if (Id < (root->data).getId()) {
		return idExists(root->left, Id);
	}
	else {
		return idExists(root->right, Id);
	}
}

int BinarySearchTree::generateID(int Id) {
	return generateID(root, Id);
}

int BinarySearchTree::generateID(BinaryNode* root, int Id) {
	if (idExists(root, Id)) {
		return generateID(root, rand() % 10000); // try again
	}
	return Id;
}

//Constructor
BinarySearchTree::BinarySearchTree() { root = nullptr; }

//Copy Constructor

BinarySearchTree::BinarySearchTree(const BinarySearchTree& bst)
{
	root = Clone(bst.root);
}

//Clone utility function
BinaryNode* BinarySearchTree::Clone(BinaryNode* tn) const
{
	if (tn == nullptr) { return nullptr; }
	return new BinaryNode(tn->data, Clone(tn->left),
		Clone(tn->right));
}

//Destructor
BinarySearchTree::~BinarySearchTree() { MakeEmpty(); }

//MakeEmpty access function
void BinarySearchTree::MakeEmpty()
{
	MakeEmpty(root);
}

//MakeEmpty utility function
void BinarySearchTree::MakeEmpty(BinaryNode*& tn)
{
	if (tn != nullptr)
	{
		MakeEmpty(tn->left);
		MakeEmpty(tn->right);
		delete tn;
	}
	tn = nullptr; //To avoid having an indeterminate value
}

//Contains access function
tree BinarySearchTree::Contains(const int& value) const
{
	return Contains(value, root);
}

//Contains utility function
tree BinarySearchTree::Contains(const int& value, BinaryNode* tn) const
{
	if (tn == nullptr)
		return tree();
	else if (value < (tn->data).getId())
		return Contains(value, tn->left);
	else if (value > (tn->data).getId())
		return Contains(value, tn->right);
	else
		return tn->data;
}
//FindMin access function
tree BinarySearchTree::FindMin() const
{
	return (IsEmpty() == true ? tree() : FindMin(root));
}
//FindMin utility function
tree BinarySearchTree::FindMin(BinaryNode* tn) const
{
	if (tn->left == nullptr)
		return tn->data;
	return FindMin(tn->left);
}

//Predicate function
bool BinarySearchTree::IsEmpty() const { return root == nullptr; }


//Insert access function
void BinarySearchTree::Insert(const tree& value)
{
	Insert(value, root);
}

//Insert utility function
void BinarySearchTree::Insert(const tree& value, BinaryNode*& tn)
{
	if (tn == nullptr)
		tn = new BinaryNode(value, nullptr, nullptr);
	else if (value.getId() < (tn->data).getId())
		Insert(value, tn->left);
	else if (value.getId() > (tn->data).getId())
		Insert(value, tn->right);
}

//Remove access function
void BinarySearchTree::Remove(const tree& value)
{
	Remove(value, root);
}

//Remove utility function
void BinarySearchTree::Remove(const tree& value, BinaryNode*& tn)
{
	if (tn == nullptr) { return; } //Value not found
	else if (value.getId() < (tn->data).getId()) { Remove(value, tn->left); }
	else if (value.getId() > (tn->data).getId()) { Remove(value, tn->right); }
	//Two child nodes (using inorder successor)
	else if (tn->left != nullptr && tn->right != nullptr)
	{
		tn->data = FindMin(tn->right);
		Remove(tn->data, tn->right);
	}
	else
	{
		BinaryNode* oldNode = tn;
		tn = (tn->left != nullptr) ? tn->left : tn->right;
		delete oldNode;
	}
}

//PrintTree access function
void BinarySearchTree::PrintTree() const
{
	PrintTree(root);
}
//PrintTree utility function
void BinarySearchTree::PrintTree(BinaryNode* tn) const
{
	if (tn != nullptr)
	{
		//Inorder traversal
		PrintTree(tn->left);
		(tn->data).printtree();
		PrintTree(tn->right);
	}
}

//PrintcuttableTree access function
void BinarySearchTree::PrintCutTree() const
{
	PrintCutTree(root);
}
//PrintcuttableTree utility function
void BinarySearchTree::PrintCutTree(BinaryNode* tn) const
{
	if (tn != nullptr)
	{
		//Inorder traversal
		PrintCutTree(tn->left);
		if ((tn->data).Iscutable(time(0)))
			(tn->data).printtree();
		PrintCutTree(tn->right);
	}
}



